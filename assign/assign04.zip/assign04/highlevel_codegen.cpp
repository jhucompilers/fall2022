#include <cassert>
#include "node.h"
#include "instruction.h"
#include "highlevel.h"
#include "ast.h"
#include "parse.tab.h"
#include "grammar_symbols.h"
#include "exceptions.h"
#include "highlevel_codegen.h"

namespace {

// Adjust an opcode for a basic type
HighLevelOpcode get_opcode(HighLevelOpcode base_opcode, const std::shared_ptr<Type> &type) {
  if (type->is_basic())
    return static_cast<HighLevelOpcode>(int(base_opcode) + int(type->get_basic_type_kind()));
  else if (type->is_pointer())
    return static_cast<HighLevelOpcode>(int(base_opcode) + int(BasicTypeKind::LONG));
  else
    RuntimeError::raise("attempt to use type '%s' as data in opcode selection", type->as_str().c_str());
}

int get_binop_opcode(int op, const std::shared_ptr<Type> &lhs_type) {
  HighLevelOpcode base_opcode;

  switch (op) {
  case TOK_PLUS:
    base_opcode = HINS_add_b; break;
  case TOK_MINUS:
    base_opcode = HINS_sub_b; break;
  case TOK_ASTERISK:
    base_opcode = HINS_mul_b; break;
  case TOK_DIVIDE:
    base_opcode = HINS_div_b; break;
  case TOK_LT:
    base_opcode = HINS_cmplt_b; break;
  case TOK_LTE:
    base_opcode = HINS_cmplte_b; break;
  case TOK_GT:
    base_opcode = HINS_cmpgt_b; break;
  case TOK_GTE:
    base_opcode = HINS_cmpgte_b; break;
  case TOK_EQUALITY:
    base_opcode = HINS_cmpeq_b; break;
  case TOK_INEQUALITY:
    base_opcode = HINS_cmpneq_b; break;
  default:
    assert(false); // not handled yet
  }

  return get_opcode(base_opcode, lhs_type);
}

}

HighLevelCodegen::HighLevelCodegen(int next_label_num)
  : m_next_label_num(next_label_num)
  , m_hl_iseq(new InstructionSequence()) {
}

HighLevelCodegen::~HighLevelCodegen() {
}

void HighLevelCodegen::visit_function_definition(Node *n) {
  // generate the name of the label that return instructions should target
  std::string fn_name = n->get_kid(1)->get_str();
  m_return_label_name = ".L" + fn_name + "_return";

  unsigned total_local_storage = 0U;
/*
  total_local_storage = n->get_total_local_storage();
*/

  m_hl_iseq->append(new Instruction(HINS_enter, Operand(Operand::IMM_IVAL, total_local_storage)));

  // visit body
  visit(n->get_kid(3));

  m_hl_iseq->define_label(m_return_label_name);
  m_hl_iseq->append(new Instruction(HINS_leave, Operand(Operand::IMM_IVAL, total_local_storage)));
  m_hl_iseq->append(new Instruction(HINS_ret));
}

void HighLevelCodegen::visit_expression_statement(Node *n) {
  // TODO: implement
}

void HighLevelCodegen::visit_return_statement(Node *n) {
  // jump to the return label
  m_hl_iseq->append(new Instruction(HINS_jmp, Operand(Operand::LABEL, m_return_label_name)));
}

void HighLevelCodegen::visit_return_expression_statement(Node *n) {
  Node *expr = n->get_kid(0);

  // generate code to evaluate the expression
  visit(expr);

  // move the computed value to the return value vreg
  HighLevelOpcode mov_opcode = get_opcode(HINS_mov_b, expr->get_type());
  m_hl_iseq->append(new Instruction(mov_opcode, Operand(Operand::VREG, LocalStorageAllocation::VREG_RETVAL), expr->get_operand()));

  // jump to the return label
  visit_return_statement(n);
}

void HighLevelCodegen::visit_while_statement(Node *n) {
  // TODO: implement
}

void HighLevelCodegen::visit_do_while_statement(Node *n) {
  // TODO: implement
}

void HighLevelCodegen::visit_for_statement(Node *n) {
  // TODO: implement
}

void HighLevelCodegen::visit_if_statement(Node *n) {
  std::string done_label = next_label();

  // evaluate condition
  visit(n->get_kid(0));

  // if condition is not true, jump to done label
  m_hl_iseq->append(new Instruction(HINS_cjmp_f, n->get_kid(0)->get_operand(), Operand(Operand::LABEL, done_label)));

  // generate code for body
  visit(n->get_kid(1));

  m_hl_iseq->define_label(done_label);
}

void HighLevelCodegen::visit_if_else_statement(Node *n) {
  std::string done_label = next_label(), iffalse_label = next_label();

  // evaluate condition
  visit(n->get_kid(0));

  // if condition is not true, jump to iffalse label
  m_hl_iseq->append(new Instruction(HINS_cjmp_f, n->get_kid(0)->get_operand(), Operand(Operand::LABEL, iffalse_label)));

  // emit if true code, then jump to done label
  visit(n->get_kid(1));
  m_hl_iseq->append(new Instruction(HINS_jmp, Operand(Operand::LABEL, done_label)));

  // emit if false code
  m_hl_iseq->define_label(iffalse_label);
  visit(n->get_kid(2));
  // fall through to done label

  // done label
  m_hl_iseq->define_label(done_label);
}

void HighLevelCodegen::visit_binary_expression(Node *n) {
  // TODO: implement
}

void HighLevelCodegen::visit_function_call_expression(Node *n) {
  // evaluate arguments, move each computed value into the approriate arg vreg
  Node *arg_expr_list = n->get_kid(1);
  int arg_vreg = LocalStorageAllocation::VREG_FIRST_ARG;
  for (auto i = arg_expr_list->cbegin(); i != arg_expr_list->cend(); ++i) {
    Node *arg_expr = *i;
    visit(arg_expr);

    std::shared_ptr<Type> arg_type = arg_expr->get_type();
    Operand arg_operand = arg_expr->get_operand();
    if (arg_type->is_array()) {
      // Special case: convert array argument to pointer
      arg_type = std::shared_ptr<Type>(new PointerType(arg_type->get_base_type()));
      assert(arg_operand.is_memref());
      assert(!arg_operand.has_index_reg());
      assert(!arg_operand.has_offset());
      arg_operand = Operand(Operand::VREG, arg_operand.get_base_reg());
    }
    HighLevelOpcode mov_opcode = get_opcode(HINS_mov_b, arg_type);
    m_hl_iseq->append(new Instruction(mov_opcode, Operand(Operand::VREG, arg_vreg++), arg_operand));
  }

  // emit call instruction
  Node *fn_node = n->get_kid(0);
  assert(fn_node->get_tag() == AST_VARIABLE_REF);
  std::string fn_name = fn_node->get_kid(0)->get_str();
  m_hl_iseq->append(new Instruction(HINS_call, Operand(Operand::LABEL, fn_name)));

  // allocate a temp vreg for the result, move the result there
  int dest_vreg = next_temp_vreg();
  Operand dest_operand(Operand::VREG, dest_vreg);
  HighLevelOpcode mov_opcode = get_opcode(HINS_mov_b, n->get_type());
  m_hl_iseq->append(new Instruction(mov_opcode, dest_operand, Operand(Operand::VREG, LocalStorageAllocation::VREG_RETVAL)));
  n->set_operand(dest_operand);
}

void HighLevelCodegen::visit_array_element_ref_expression(Node *n) {
  // TODO: implement
}

void HighLevelCodegen::visit_variable_ref(Node *n) {
  // Note: this works for both lvalues and rvalues!
  // In either case, we just want to know the storage location where
  // a value is available, or where a value should be stored.

  Operand storage = determine_storage_location(n);
  n->set_operand(storage);
}

void HighLevelCodegen::visit_literal_value(Node *n) {
  LiteralValue val = n->get_literal_value();
  int vreg = next_temp_vreg();
  Operand dest(Operand::VREG, vreg);
  HighLevelOpcode mov_opcode = get_opcode(HINS_mov_b, n->get_type());
  m_hl_iseq->append(new Instruction(mov_opcode, dest, Operand(Operand::IMM_IVAL, val.get_int_value())));
  n->set_operand(dest);
}

std::string HighLevelCodegen::next_label() {
  std::string label = ".L" + std::to_string(m_next_label_num++);
  return label;
}

// TODO: additional private member functions
