#include "module_collector.h"

ModuleCollector::ModuleCollector() {
}

ModuleCollector::~ModuleCollector() {
}
