#ifndef CFG_TRANSFORM_H
#define CFG_TRANSFORM_H

#include <memory>
#include "cfg.h"

class ControlFlowGraphTransform {
private:
  std::shared_ptr<ControlFlowGraph> m_cfg;

public:
  ControlFlowGraphTransform(const std::shared_ptr<ControlFlowGraph> &cfg);
  virtual ~ControlFlowGraphTransform();

  std::shared_ptr<ControlFlowGraph> get_orig_cfg();

  virtual std::shared_ptr<ControlFlowGraph> transform_cfg();

  // Transform orig_bb by adding instructions to transformed_bb.
  // Important: Instruction objects are owned by the BasicBlock, so do
  // NOT just add a pointer to an Instruction object owned by orig_bb
  // to transformed_bb. You can duplicate an Instruction using the code
  //
  //   Instruction *ins = /* an instruction in the original BasicBlock */;
  //   Instruction *dup_ins = ins->duplicate();
  //
  // and then add the duplicate to the transformed BasicBlock.
  virtual void transform_basic_block(BasicBlock *orig_bb, BasicBlock *transformed_bb) = 0;
};

#endif // CFG_TRANSFORM_H
